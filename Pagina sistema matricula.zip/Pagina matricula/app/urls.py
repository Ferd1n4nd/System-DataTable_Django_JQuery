from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('list_alumnos/', views.list_alumnos, name='list_alumnos'),
    path('list_cursos/<int:semestre>/', views.list_cursos, name='list_cursos'),
]
