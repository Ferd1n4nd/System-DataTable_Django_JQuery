const dataTableOptions = {
    columnDefs: [
        { className: "centered", targets: [0, 1, 2, 3, 4, 5] },
        { orderable: false, targets: [0] },
        { searchable: false, targets: [0] }
    ],
    language: {
        processing: "Procesando...",
        lengthMenu: "Mostrar _MENU_ registros por página",
        zeroRecords: "No se encontraron resultados",
        info: "Mostrando de _START_ a _END_ de _TOTAL_ registros",
        infoEmpty: "Mostrando de 0 a 0 de 0 registros",
        infoFiltered: "(filtrado de _MAX_ registros totales)",
        search: "Buscar:",
        paginate: {
            first: "Primero",
            previous: "Anterior",
            next: "Siguiente",
            last: "Último"
        },
        aria: {
            sortAscending: ": activar para ordenar la columna de manera ascendente",
            sortDescending: ": activar para ordenar la columna de manera descendente"
        }
    },
    pageLength: 15,
    destroy: true
};

let dataTable;
let dataTableIsInitialized = false;

const initDataTable = async () => {
    if (dataTableIsInitialized) {
        dataTable.destroy();
    }

    await listAlumnos();

    dataTable = $('#datatable-alumnos').DataTable({
        ...dataTableOptions,
        initComplete: function () {
            this.api().columns().every(function (index) {
                if (index > 0) {
                    var column = this;

                    $('<input type="text" placeholder="Buscar..." />')
                        .appendTo($(column.footer()).empty())
                        .on('keyup change clear', function () {
                            if (column.search() !== this.value) {
                                column.search(this.value).draw();
                            }
                        });
                }
            });
        }
    });

    $('#datatable-alumnos tbody').on('click', 'td.details-control', function () {
        var tr = $(this).closest('tr');
        var row = dataTable.row(tr);

        if (row.child.isShown()) {
            row.child.hide();
        } else {
            format(row.data()).then(html => {
                row.child(html).show();
            });
        }
    });

    dataTableIsInitialized = true;
};

const format = async (d) => {
    const semestre = d[4];

    try {
        const response = await fetch(`http://127.0.0.1:8000/app/list_cursos/${semestre}/`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();

        let tableHtml = '<table border="1" style="width:100%;"><tr><th>Nombre</th><th>ID</th><th>Créditos</th></tr>';
        data.cursos.forEach(curso => {
            tableHtml += `<tr><td>${curso.nombre}</td><td>${curso.id}</td><td>${curso.creditos}</td></tr>`;
        });
        tableHtml += '</table>';

        return `<p>CURSOS:</p>${tableHtml}`;
    } catch (error) {
        console.error('Error al obtener los cursos del semestre:', error);
        return '<p>Error al obtener los cursos del semestre</p>';
    }
};

const listAlumnos = async () => {
    try {
        const response = await fetch('http://127.0.0.1:8000/app/list_alumnos/');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();

        let content = '';
        data.alumnos.forEach((alumno, index) => {
            content += `
                <tr>
                    <td class="details-control">${index + 1}</td>
                    <td>${alumno.nombre}</td>
                    <td>${alumno.apellido}</td>
                    <td>${alumno.cui}</td>
                    <td>${alumno.semestre}</td>
                    <td>${alumno.correo}</td>
                </tr>
            `;
        });
        document.getElementById('tableBody_alumnos').innerHTML = content;
    } catch (ex) {
        alert(ex);
    }
};

window.addEventListener('load', async () => {
    await initDataTable();
});
