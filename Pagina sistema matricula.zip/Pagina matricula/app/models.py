from django.db import models

# Create your models here.


class Student(models.Model):
    cui = models.IntegerField(primary_key=True)
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    creditos = models.IntegerField()
    semestre = models.IntegerField()
    correo = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'alumnos'


class Cursos(models.Model):
    id = models.IntegerField(primary_key=True)
    nombre = models.CharField(max_length=100)
    creditos = models.IntegerField()
    semestre = models.IntegerField()
    cupos = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'cursos'
