from django.http.response import JsonResponse
from django.shortcuts import render
from .models import Student
from .models import Cursos

# Create your views here.


def index(request):
    return render(request, 'index.html')


def list_alumnos(request):
    alumnos = list(Student.objects.values())
    data = {'alumnos': alumnos}
    return JsonResponse(data)


def list_cursos(request, semestre):
    cursos = list(Cursos.objects.filter(
        semestre=semestre).values('nombre', 'id', 'creditos'))
    data = {'cursos': cursos}
    return JsonResponse(data)
